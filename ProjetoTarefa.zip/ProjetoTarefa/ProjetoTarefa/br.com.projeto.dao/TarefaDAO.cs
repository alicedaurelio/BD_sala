﻿using MySql.Data.MySqlClient;
using ProjetoTarefa.br.com.projeto.conexao;
using ProjetoTarefa.br.com.projeto.model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProjetoTarefa.br.com.projeto.dao
{
    public class TarefaDAO
    {
        private MySqlConnection conexao;

        public TarefaDAO()
        {
            this.conexao = new ConnectionFactory().GetConnection();
        }

        public void AdicionarTarefa(Tarefa obj)
        {
            try
            {
                string sql = "insert into tbtarefa (titulo, assunto) values (@titulo, @assunto)";

                MySqlCommand executacmd = new MySqlCommand(sql, conexao);
                executacmd.Parameters.AddWithValue("@titulo", obj.titulo);
                executacmd.Parameters.AddWithValue("@assunto", obj.assunto);

                conexao.Open();
                executacmd.ExecuteNonQuery();

                MessageBox.Show("Tarefa cadastrado com sucesso");

                conexao.Close();

            }
            catch (Exception erro)
            {
                MessageBox.Show("Aconteceu o erro: " + erro);
            } 

        }

    }
}
